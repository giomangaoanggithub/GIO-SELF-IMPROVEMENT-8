<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM ((student_answers LEFT JOIN created_questions ON student_answers.question_id = created_questions.question_id) INNER JOIN user_accounts ON student_answers.owner_student = user_accounts.email) INNER JOIN classrooms ON created_questions.classroom_id = classrooms.room_id WHERE owner_teacher = '$email' AND checked = '0'ORDER BY re_eval DESC;");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);
    
    $_SESSION["curr_superior"] = $result[0]["admin_email"];

    echo json_encode($result);

  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;

?>